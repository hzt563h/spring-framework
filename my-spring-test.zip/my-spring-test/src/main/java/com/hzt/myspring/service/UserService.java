package com.hzt.myspring.service;

public interface UserService {
}
